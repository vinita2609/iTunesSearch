package com.example.itunesapi.util

const val BASE_URL: String = "https://itunes.apple.com"