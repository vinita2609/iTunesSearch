package com.example.itunesapi.viewmodel

import androidx.lifecycle.ViewModel
import com.example.itunesapi.injection.component.DaggerViewModelInjector
import com.example.itunesapi.injection.component.ViewModelInjector
import com.example.itunesapi.ui.ItunesSearchViewModel
import com.example.itunesapi.injection.module.NetworkModule

abstract class BaseViewModel:ViewModel() {

    private val injector: ViewModelInjector = DaggerViewModelInjector
        .builder()
        .networkModule(NetworkModule)
        .build()

    init {
        inject()
    }

    /**
     * Injects the required dependencies
     */
    private fun inject() {
        when (this) {
            is ItunesSearchViewModel -> injector.inject(this)
        }
    }

}